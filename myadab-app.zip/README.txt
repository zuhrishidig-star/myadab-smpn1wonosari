MyADAB — Aplikasi Data Akhlak dan Budi Luhur
SMPN 1 Wonosari
=================================================

Paket ini adalah aplikasi versi awal (PWA) yang BISA DIPASANG di HP Android
seperti aplikasi biasa. Isinya:
  - index.html      (aplikasi)
  - manifest.json   (identitas aplikasi: nama, ikon)
  - sw.js           (agar bisa dibuka offline & memenuhi syarat "pasang")
  - icon-192.png, icon-512.png (ikon aplikasi)

SEMUA FILE INI HARUS BERADA DALAM SATU FOLDER YANG SAMA.

-------------------------------------------------
LANGKAH 1 — TARUH DI INTERNET (HOSTING GRATIS)
-------------------------------------------------
Aplikasi web perlu alamat (https) agar bisa dipasang & memakai kamera/GPS.
Pilih salah satu cara termudah:

A. Netlify Drop (paling cepat, tanpa akun teknis)
   1. Buka https://app.netlify.com/drop
   2. Seret-jatuhkan SELURUH folder ini ke halaman tersebut.
   3. Netlify memberi alamat seperti https://nama-acak.netlify.app
   4. Alamat itulah yang dibuka di HP.

B. GitHub Pages (gratis, lebih permanen)
   1. Buat repository baru di github.com, unggah semua file ini.
   2. Settings > Pages > pilih branch "main" > Save.
   3. Tunggu, lalu buka alamat https://username.github.io/nama-repo/

-------------------------------------------------
LANGKAH 2 — PASANG DI HP ANDROID
-------------------------------------------------
1. Buka alamat tadi di Google Chrome pada HP Android.
2. Akan muncul tombol "Pasang" di aplikasi, ATAU buka menu Chrome (⋮)
   lalu pilih "Tambahkan ke layar utama" / "Pasang aplikasi".
3. Selesai — ikon MyADAB muncul di layar HP, terbuka layar penuh.

Untuk DEVICE ABSENSI di gerbang: pasang dengan cara yang sama di tablet/HP
khusus, lalu buka tab "Device Absensi".

-------------------------------------------------
CATATAN PENTING
-------------------------------------------------
- Versi ini adalah FRONT-END. Data tersimpan di HP masing-masing
  (belum terpusat antar pengguna).
- Agar BENAR-BENAR berfungsi penuh — data terpusat, notifikasi WhatsApp
  nyata ke orang tua/Tim Tatib, login per peran — diperlukan SERVER
  (database + WhatsApp gateway/API + hosting). Bagian ini tahap berikutnya.
- Koordinat sekolah untuk validasi GPS ada di index.html (cari "SCHOOL").
  Ganti lat/lng sesuai lokasi gerbang sekolah.
- Ingin jadi APK untuk Play Store? Setelah aplikasi online (Langkah 1),
  buka https://www.pwabuilder.com, masukkan alamatnya, dan unduh paket Android.

Prototipe/aplikasi awal — data & foto hanya contoh, bukan data nyata.
